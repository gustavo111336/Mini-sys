#!/bin/bash
# ========================================================
# ENCRONTER ENGINE - VALIDADOR DE BOOT V2
# ========================================================

TARGET_ISO="./Vendor/Boot.iso"

# Função simples de contagem (sem erro de -e)
check_tags() {
    TAG_ABERTA=$(grep -c "\.$1" "$TARGET_ISO")
    TAG_FECHADA=$(grep -c "\./$1" "$TARGET_ISO")
    
    printf "Analisando bloco [$1]: "
    
    if [ "$TAG_ABERTA" -eq "$TAG_FECHADA" ] && [ "$TAG_ABERTA" -gt 0 ]; then
        printf "\033[1;32m[OK] ($TAG_ABERTA)\033[0m\n"
        return 0
    else
        printf "\033[1;31m[FALHA] (Abertas: $TAG_ABERTA | Fechadas: $TAG_FECHADA)\033[0m\n"
        return 1
    fi
}

clear
echo "=========================================="
echo "      VERIFICADOR DE INTEGRIDADE ISO      "
echo "=========================================="

ERRORS=0

# Valida cada tag que você criou no Acode
check_tags "start.iso" || ERRORS=$((ERRORS + 1))
check_tags "mode-start" || ERRORS=$((ERRORS + 1))

echo "------------------------------------------"

if [ "$ERRORS" -eq 0 ]; then
    echo "ESTADO: SISTEMA ÍNTEGRO"
    # Aqui o negócio "pega" e continua o boot
    exit 0
else
    echo "ESTADO: $ERRORS ERRO(S) DE SINTAXE ENCONTRADOS"
    echo "Dica: Verifique se esqueceu o '.' ou a '/' no Acode."
    exit 1
fi
