# Script para ganhar privilégios via ADB na v0.3
echo "A conectar ao núcleo do sistema..."
adb connect localhost:5555
adb shell "setenforce 0" 2>/dev/null
echo "SELinux agora está em modo passivo para o Mini-sys!"
