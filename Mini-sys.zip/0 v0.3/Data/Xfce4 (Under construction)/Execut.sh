curl -sL https://raw.githubusercontent.com/AndronixApp/AndronixOrigin/master/Repo/XFCE4/xfce4_install.sh | bash
