#!/bin/bash
clear
echo "--- INICIANDO NEONUX OS (2026) ---"

# 1. Verifica o motor na raiz
if [ -d "fireware/kernel" ]; then
    echo "[OK] Kernel oficial localizado na Raiz."
else
    echo "[ERRO] Kernel não encontrado em Fireware/kernel!"
    exit
fi

# 2. Carrega as specs da pasta System
if [ -f "System/ro.prop" ]; then
    RAM=$(grep "ro.config.ram_size" System/ro.prop | cut -d'=' -f2)
    echo "[INFO] RAM: $RAM MB carregada."
else
    echo "[ERRO] Arquivo de propriedades sumiu da System!"
    exit
fi

echo "--- STATUS: DONO DA INTERNET ---"
# O comando abaixo segura o script aberto
echo "Pressione Enter para entrar no shell do Neonux..."
read input
# Entrando no Modo Shell do Neonux
while true; do
    echo -n "neonux@goonux:~$ "
    read cmd
    
    case $cmd in
        "info")
            echo "Neonux OS v16 | Kernel: 2026-Stable | RAM: 868192MB"
            ;;
        "ls system")
            ls System
            ;;
        "sair")
            echo "Desligando o Dono da Internet..."
            break
            ;;
        "help")
            echo "Comandos: info, ls system, sair, help"
            ;;
        *)
            echo "Comando '$cmd' não reconhecido pelo Kernel."
            ;;
    esac
done
