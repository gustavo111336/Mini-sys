# Simulação de leitura de Hardware
RAM=$(grep "ro.config.ram_size" ro.prop | cut -d'=' -f2)
STORAGE=$(grep "ro.product.storage.total" ro.prop | cut -d'=' -f2)

echo "--- NEONUX HARDWARE INFO ---"
echo "RAM: $((RAM / 1024)) GB"
echo "Armazenamento: $STORAGE"
