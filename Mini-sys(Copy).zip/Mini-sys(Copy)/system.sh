#!/bin/bash
# system.sh - Versão Final de Identificação

# O xargs remove espaços em branco invisíveis que o Acode pode ter inserido
NIVEL=$(grep "usuario.nivel" System/Product.prop | cut -d'=' -f2 | xargs)

# No 'sh' do Android, use apenas um '=' para comparar texto
if [ "$NIVEL" = "admin" ]; then
    echo "Bem-vindo, Administrador do Vm-World!"
else
    echo "Acesso como Usuário Comum. (Valor lido: '$NIVEL')"
fi
